import { useEffect } from 'react';
import React from 'react';
import { useLocation } from 'react-router-dom';

function Patient() {
  const l = useLocation();
  const data = l.state;
 const hospId=data.hospId;
  const docId=data.docId;
  const name=data.name;
   const slotId=data.slot;
  const date=data.date;

  


  useEffect(() => {
    // Set state values after the component mount
    console.log("here",data);
     console.log("hospId",hospId);
     console.log("docId",docId);
     console.log("name",name);
     console.log("slotId",slotId);
    console.log("date",date);



  }, [data]);

  return (
    <div>
      patient
    </div>
  );
}

export default Patient;
