import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { DayPicker } from 'react-day-picker';

function Booking(props) {
  const { hospId, docId, name ,hospname} = props;
  const [selectedDate, setSelectedDate] = useState(null);
  const [date, setDate] = useState('');
  const [slots, setSlots] = useState([]);
  const[time,setTime]=useState("");
  const [noSlotsMessage, setNoSlotsMessage] = useState('');
  const [slot,setSlot]=useState('0');
  const data={hospId:hospId,docId:docId,name:name,date:date,slot:slot,hospname:hospname,time:time};

  const handleGetSlots = async () => {
    try {
      if (!docId || !hospId || !selectedDate) {
        setNoSlotsMessage('Please enter valid Doctor ID, Hospital ID, and Date.');
        return;
      }

      const formattedDate = `${selectedDate.getFullYear()}-${selectedDate.getMonth() + 1}-${selectedDate.getDate()}`;

      const allSlotsResponse = await axios.get('http://localhost:3001/slot', {
        params: {
          docId,
          hospId,
          date: formattedDate,
        },
      });

      const availableSlotsResponse = await axios.get('http://localhost:3001/availableSlots', {
        params: {
          docId,
          hospId,
          date: formattedDate,
        },
      });

      const availableSlots = Array.isArray(availableSlotsResponse.data.availableSlots)
        ? availableSlotsResponse.data.availableSlots
        : [];

      setSlots(availableSlots);

      if (availableSlots.length === 0) {
        setNoSlotsMessage('No slots available for the selected day. Please select a valid day.');
      } else {
        setNoSlotsMessage('');
      }
    } catch (error) {
      console.error('Error fetching slots:', error);
      setNoSlotsMessage('Error fetching slots. Please try again.');
    }
  };

  useEffect(() => {
    console.log('Slots:', slots);
    console.log(name);
  }, [slots]);

  const isSunday = (date) => date.getDay() === 0;
  const isPastDate = (date) => date < new Date();
  const disabledDates = { before: new Date(), daysOfWeek: [0] };

  const handleDateChange = (selectedDate) => {
    const currentDate = new Date();
    const selectedDateObj = new Date(selectedDate);

    if (!isSunday(selectedDateObj) && !isPastDate(selectedDateObj)) {
      const formattedDate = `${selectedDate.getFullYear()}-${selectedDate.getMonth() + 1}-${selectedDate.getDate()}`;
      setDate(formattedDate);
      setSelectedDate(selectedDateObj);
    }
  };

  const handleSlotClick = (slot) => {
    console.log(`Slot ${slot.slot_id} clicked!`);
    setSlot(slot.slot_id);
    setTime(slot.booking_time);
    console.log("t",time);
    console.log(data);
    // Add logic for handling slot click
  };

  return (
    <div style={{ padding: '20px' }}>
      <label>Choose Appointment Date</label>
      <DayPicker
        mode='single'
        selected={selectedDate}
        onSelect={handleDateChange}
        initialFocus
        disabled={disabledDates}
      />

      <button style={{ margin: '10px 0' }} onClick={handleGetSlots}>
        View Available Slots
      </button>

      {noSlotsMessage && <p style={{ color: 'red' }}>{noSlotsMessage}</p>}
      {slots.length > 0 && (
        <div>
          <h2>Available Slots:</h2>
          <ul style={{ listStyleType: 'none', padding: 0 }}>
            {slots.map((slot) => (
              <li key={slot.slot_id} style={{ margin: '5px 0' }}>
                <button onClick={() => handleSlotClick(slot)}>
                  {slot.booking_time ?? 'N/A'}
                </button>
              
              </li>
            ))}
          </ul>
          <div className="confirm">
          <Link to={`/Patient`}  state={data}> <button>Book Now</button></Link>
          </div>
        </div>
      )}
    </div>
  );
}

export default Booking;
