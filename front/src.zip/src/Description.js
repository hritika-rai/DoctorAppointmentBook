import React, { useState,useEffect } from 'react';
import { useParams,Link } from 'react-router-dom';
import Axios from "axios";
import Booking from "./Booking";



function Description() {
  const [showBooking, setShowBooking] = useState(false);
const [result,setResult]=useState([]);
const [hospitals,setHospitals]=useState([]);
const [hospid,setHospid]=useState(0);
  const {id} = useParams();
  let f=0;
  console.log({id});

  useEffect(() => {
      getInformation();
       getInformation2();
     
   }, []);
  
  const getInformation = () => {
      Axios.get("http://localhost:3001/GetDoctor",{ params: {id } })
        .then((response) => {
      //    setResult(response.data[0][4]);
          setResult(response.data);
          const data = response.data[0];
        console.log('Response:', data); // Log the entire response object
          console.log('Data:', response.data); // Log the data
          console.log("out",result);
        })
        .catch((error) => {
          console.error(error);
        });
    };

    const getInformation2 = () => {
      Axios.get("http://localhost:3001/GetHospitals",{ params: {id } })
        .then((response) => {
      //    setResult(response.data[0][4]);
          setHospitals(response.data);
          const data = response.data[0];
        console.log('Response:', data); // Log the entire response object
          console.log('Data:', response.data); // Log the data
          console.log("out",result);
        })
        .catch((error) => {
          console.error(error);
        });
    };




const displayHospital=()=>{

  return hospitals.map((val, key) => {
    return (
   <div >
      <div  key={key}>
        <div  >
        
        <div><button onClick={() => {setHospid(val[0]);console.log(hospid);setShowBooking(true);}}>{val[1]}</button></div>
            

       
        </div>
      </div>
      
    
      </div>
    )
  })
};


    const displayAll = () => {
  
     
      return (result.map((val, key) => {
          return (
         <div >
            <div  key={key}>
              <div  >
              <div><img src={val[6]} alt="Image" style={{ width: '100px', height: 'auto' }} /> </div>
              <div>rev num:{val[8]}</div>
       <div>patient num:{val[9]}</div>
       <div>experience:{val[10]}</div>
              <div>Name:{val[0]}</div>
               {/* <div>{val[1]}</div> */}
               <div>Speciality:{val[2]}</div>
               <div>Fees:{val[3]}/-</div>
              
               <div>Rating:{val[5]}</div>
              
               <div>Description:{val[7]}</div>
       
       <div>Review:{val[4]}</div>
              
               {/* <Link to={`/Cart`} state={data} onClick={handleAddToCart}><button>Add To Cart</button></Link>
               */}
  
   
             
              </div>
            </div>
            
          
            </div>
          )
        })
        

      )
      };

  return (
    <div>
      
      {displayAll()}
      {displayHospital()}
      {showBooking && <Booking />}
    </div>
  );
}

export default Description;
