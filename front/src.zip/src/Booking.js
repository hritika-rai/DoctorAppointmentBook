import React from 'react'

function Booking() {
  return (
    <div>
      hello world ?
    </div>
  )
}

export default Booking;
